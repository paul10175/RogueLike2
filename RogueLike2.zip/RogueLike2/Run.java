
public class Run {

	public static void main(String[] args) {
		EngineCore core = new EngineCore(10, 2, 2, "hello", "/home/jkuo147/Documents/git/RogueLike2/Assets");
		core.start();
		core.run();
	}
}
